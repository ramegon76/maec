
##### Ejercicio 1

Y <-c(21.65,13.88,20.81,30.43,12.32,20.11,18.30,17.59,20.63,
      19.53,23.42,22.15,23.20,19.27,20.01)
n <- length(Y1)
X1 <- c(9.30,0.72,3.64,8.95,0.97,3.14,1.89,
        1.21,8.01,6.96,8.01,5.91,4.68,3.26,3.77)
X2 <- c(1.31,1.38,3.13,4.99,1.03,3.34,3.56,
        3.71,1.09,1.67,1.97,2.47,4.54,3.71,3.10)

X <- cbind(rep(1,n),c(9.30,0.72,3.64,8.95,0.97,3.14,1.89,
                      1.21,8.01,6.96,8.01,5.91,4.68,3.26,3.77),
           c(1.31,1.38,3.13,4.99,1.03,3.34,3.56,
             3.71,1.09,1.67,1.97,2.47,4.54,3.71,3.10))

mod1 <- lm(Y~X1+X2)
summary(mod1)
plot(mod1)
confint(mod1)

# Betas:

B <- solve(t(X) %*% X) %*% (t(X) %*% Y)
B
#

# Ajustados:

Y_aj <- X %*% B
Y_aj
#

# Residuales:

e <- Y - Y_aj
e



# Cuadrado medio de residuos:

CMe <- as.numeric((t(Y)%*%Y - 
                      t(B)%*%t(X)%*%Y)/(n-3))
CMe
# 

# Varianza de las betas:

Var_beta <- solve(t(X)%*%X) * CMe
Var_beta
#

# Intervalo de confianza del Intercepto:

c(B[1,1] - qt(p=0.975,df=n-3) * sqrt(Var_beta[1,1]),
  B[1,1] + qt(p=0.975,df=n-3) * sqrt(Var_beta[1,1]))
#

# Intervalo de confianza de las pendientes:

c(B[2,1] - qt(p=0.975,df=n-3) * sqrt(Var_beta[2,2]),
  B[2,1] + qt(p=0.975,df=n-3) * sqrt(Var_beta[2,2]))

c(B[3,1] - qt(p=0.975,df=n-3) * sqrt(Var_beta[3,3]),
  B[3,1] + qt(p=0.975,df=n-3) * sqrt(Var_beta[3,3]))

confint(mod1)


# Suma de cuadrados total:
ss_tot <- sum(Y^2)
ss_tot

# Suma de cuadrados del modelo:
ss_mod <- sum(Y_aj^2)
ss_mod

# Suma de cuadrados de residuales:

ss_resid2 <- sum(e^2)
ss_resid2

# Cuadrado medio de los residuos:

ms_resid <- ss_resid2/(n-3)
ms_resid

# Estadístico t:

mat_C <- solve(t(X) %*% X)
est_t <- B[1,1]/(sqrt(ms_resid*mat_C[1,1]))
est_t

# P-valor del estadístico t:

2*(1-pt(q=est_t,df=(n-3)))
qt(p=0.975,df=(n-3))

summary(mod1)

# error estandar de la estimación
sqrt(sum(e**2)/(n-3))
sqrt(ms_resid)










##### Ejercicio 3