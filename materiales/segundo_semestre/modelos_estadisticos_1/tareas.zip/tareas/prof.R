cells <- c(478,1907,2258,2329,1238,1491,1518,764,
           1367,328,185,342,310,278,259,249,298,
           243,210,138,160,120,90,100,313,182,144)
ca <- c(25,102,149,160,75,100,99,50,100,52,51,100,
        100,107,107,102,110,107,100,113,144,106,
        111,132,419,225,206)
doseamt <- as.factor(c(1,1,1,1,1,1,1,1,1,2.5,2.5,
                       2.5,2.5,2.5,2.5,2.5,2.5,
                       2.5,5,5,5,5,5,5,5,5,5))
doserate <- c(0.1,0.25,0.5,1,1.5,2,2.5,3,4,0.1,
              0.25,0.5,1,1.5,2,2.5,3,4,0.1,0.25,
              0.5,1,1.5,2,2.5,3,4)


mod1 <- glm(ca[-19] ~ doseamt[-19] + log(doserate[-19]), family = poisson, offset = log(cells[-19]))
summary(mod1)  

datos <- data.frame(cells,ca,doseamt,doserate)


library(ggplot2)
ggplot(datos, aes(x = log(doserate), y = ca,
                      color = doseamt)) + geom_boxplot() + theme_bw()


ggplot(datos, aes(x =  log(doserate), y = ca, group = doseamt, color = doseamt)) +
  stat_summary(fun.y = mean, geom = "point") +
  stat_summary(fun.y = mean, geom = "line") +
  theme_bw()

mod2 <- glm(ca[-19] ~ doseamt[-19] * log(doserate[-19]), 
            family = poisson, offset = log(cells[-19]))
summary(mod2)

anova(mod2, mod1)

plot(mod1)
plot(mod2)






# problema 2

fuerza <- c(40,150,350,40,150,350)
j <- as.factor(c(1,1,1,2,2,2))
y <- c(55,52,57,55,50,50)
n <- c(102,99,108,76,81,90)
vr <- cbind(y, n-y)

mod3 <- glm(vr ~ log(fuerza), family = binomial)
summary(mod3)
confint(mod3)

mod4 <- glm(vr ~ log(fuerza) + j, family = binomial)
summary(mod4)
confint(mod4)

mod5 <- glm(vr ~ log(fuerza) * j, family = binomial)
summary(mod5)
confint(mod5)

anova(mod3)

predict(mod3)
