
x <- c(161,99,135,120,164,221,179,204,214,101,231,206,248,107,205)
Localizacion <- as.factor(c("Colonia","Colonia","Colonia","Colonia","Colonia","Centro Com.",
         "Centro Com.","Centro Com.","Centro Com.","Centro Com.",
         "Centro","Centro","Centro","Centro","Centro"))
y <- c(157.27,93.28,136.81,123.79,153.51,241.74,201.54,206.71,229.78,
       135.22,224.71,195.29,242.16,115.21,197.82)

mod1 <- lm(y ~ x + Localizacion)
summary(mod1)
confint(mod1)

mod1a <- lm(y ~ x + relevel(Localizacion, "Centro Com."))
summary(mod1a)
confint(mod1a)

mod1b <- lm(y ~ x + relevel(Localizacion, "Colonia"))
summary(mod1b)
confint(mod1b)



boxplot(y ~ Localizacion)
pairwise.t.test(y, Localizacion, p.adjust = "bonferroni")
summary(mod1)$coefficients

library(ggplot2)
datos <- data.frame(x,y,Localizacion)
ggplot(datos, aes(x=x, y=y, group=Localizacion, 
                  color=Localizacion, shape=Localizacion)) + 
  geom_point() + theme_light() +
  labs(title="Diagrama de dispersión con sus curvas de regresión", 
       x="Número de casas (miles)", y="Ventas en miles de $USD") +
       geom_segment(aes(y = mod1$fitted.values[14], x = x[14], 
                        yend = mod1$fitted.values[13], xend = x[13], 
                        colour = "Centro")) +
       geom_segment(aes(y = mod1$fitted.values[10], x = x[10], 
                   yend = mod1$fitted.values[6], xend = x[6], 
                   colour = "Centro Com.")) +
      geom_segment(aes(y = mod1$fitted.values[2], x = x[2], 
                   yend = mod1$fitted.values[5], xend = x[5], 
                   colour = "Colonia"))

tab1 <- cbind(summary(mod1)$coefficients[-2,],confint(mod1)[-2,])
rownames(tab1) <- c("Centro","Centro Com.","Colonia")
tab1

relevel(Localizacion, "Centro Com.")










dosis <- 0:5
m_leuc <- c(13,5,5,3,4,18)
m_ot_canc <- c(378,200,151,47,31,33)
muertes <- cbind(m_leuc,m_ot_canc)
mod1 <- glm(muertes ~ dosis, family = "binomial")
summary(mod1)

par(mfrow=c(2,2))
plot(mod1)
shapiro.test(mod1$residuals)
mod1$fitted.values

par(mfrow=c(1,1))
prop_leuc <- m_leuc/(m_leuc+m_ot_canc)
plot(dosis,prop_leuc, xlab = "Dosis", ylab = "Proporción de muertes por leucemia",
     main = "Observaciones y ajustados del modelo con x = Dosis")
lines(dosis, mod1$fitted.values, type = "l", col="red")
legend(x = "topleft", legend = "Ajustados", fill=c("red"))

dosis2 <- dosis^2

mod2 <- glm(muertes ~ dosis + dosis2, family = "binomial")
summary(mod2)


mod4 <- glm(muertes ~ dosis2, family = "binomial")
summary(mod4)

anova(mod2, mod4)

inventos <- c(5,12,3,2,3,3,6,2,0,10,5,1,2,9,8,
              3,0,2,3,4,3,3,6,2,2,7,6,2,3,7,
              0,1,6,2,5,1,1,3,2,1,2,3,2,2,1,
              6,2,1,2,2,6,4,1,4,3,4,3,3,4,3,
              3,5,4,2,3,2,2,1,5,2,2,4,2,4,4,
              1,4,0,7,1,4,4,5,1,0,2,3,0,2,5,
              3,0,3,2,0,2,7,3,2,0)
anios <- 1:100
anios2 <- 1860:1959
mod5 <- glm(inventos ~ anios, family = "poisson")
summary(mod5)
confint(mod5)

mod5a <- lm(inventos ~ anios)
summary(mod5a)

exp(1.439204-0.006436*100)
