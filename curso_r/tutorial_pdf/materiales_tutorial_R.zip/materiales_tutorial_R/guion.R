
###########################################
##### Gui?n para el curso b?sico de R #####
###########################################


############## Directorio #################

setwd("D:/DDCETE/Cursos a personal del ?rea/Curso b?sico de R/Carpeta del curso R") ## M?quina de oficina
setwd("C:/Users/RA?L/Documents/Ra?l/Inegi") ## Casa
setwd("") ## Meebox 




############## Ejercicio 3 ################

# Corre las siguientes l?neas: 

# El M?todo de Newton-Raphson es un m?todo num?rico muy eficiente para 
# hallar las ra?ces de una funci?n, en ocasiones puede experimentar
# dificultades con la convergencia en los siguentes casos: no existe ra?z real, 
# la ra?z es un punto de inflexi?n, la aproximaci?n inicial (x0) est? muy lejos 
# de la ra?z buscada o si la derivada evaluada en un punto vale cero.
# Para evitar este problema, el siguiente algoritmo impone una restricci?n 
# referente al n?mero de iteraciones permitidas (1000 iteraciones).
# Se incluye tambi?n una gr?fica que ilustra los pasos seguidos por el m?todo
# para hallar la ra?z.

## Se define una funci?n de manera arbitraria ##

f <- function(x){ x^2-2*x-16 }
f_derivada <- function(x){ 2*x-2 }
x0 <- 0.5
epsilon <- 1e-6
maxiter <- 1000

## Algoritmo del m?todo num?rico ##

newtonraphson<-function(f,f_derivada,x0,epsilon,maxiter)
{ iter <- 0
  xold <- x0
  aproxim <- xold
  error <- 1
  while (error > epsilon & iter < maxiter)
  {
    if(f_derivada(xold) != 0)
    xnew <- xold - (f(xold)/f_derivada(xold)) 
    else stop("Se ha detectado un m?ximo o m?nimo en x0, intente con otro valor")
    error <- abs(xnew-xold)
    aproxim <- c(aproxim, xnew)
    xold <- xnew
    iter <- iter + 1
  }
  if (iter == 1000) 
    stop("Se ha alcanzado el n?mero m?ximo de iteraciones. 
         Puede intentar con otro valor de x0, aunque
         es posible que la funci?n no tenga raices reales")
  else aproxim }

##  Presenta resultados: ##
pasos <- newtonraphson(f,f_derivada,x0,epsilon,maxiter)   # Aproximaciones
pasos
print(c("N?mero de iteraciones:",length(pasos)))
print(c("Ra?z =",pasos[length(pasos)]))

## Gr?fica ##

dom <- (min(pasos)-1):(max(pasos)+1)    
plot(dom, f(dom), type = 'l', col= 'blue', lwd=2, xlab="x", ylab="f(x)",
     main='Visualizaci?n gr?fica del m?todo de Newton-Raphson')
for (i in 1:(length(pasos)-1)) {
  tang <- function (x) { f(pasos[i]) - f_derivada(pasos[i])*pasos[i] + f_derivada(pasos[i])*x }
  segments(pasos[i],0,pasos[i],f(pasos[i]), col= 'blueviolet')
  lines(c(pasos[i],pasos[i+1]),tang(c(pasos[i],pasos[i+1])), col='red')
 }
for (i in 1:4) {
  text(pasos[i], 0, paste("x",i-1), pos=1, cex= 0.7)
  text(pasos[i], f(pasos[i]), paste("f(x)",i-1), pos=3, cex= 0.7)
   }   
abline(0,0)

########## Fin del Ejercicio 3 ############




############# Tipos de Datos ##############

c(T,T,T,F)
c(21.5,55.3,12)
scan() # Teclea en la consola: 24, (Enter), 55, (Enter), 67, (Enter 2 veces)
c(T,F,12.3)
c(8.3,12+3i)
c(F,12.3,'hola')
mode(c(F,12.3,'hola'))
length(c(T,T,T,F))

a <- c(34,8,2,54,49,1) 
a 
dim(a) <- c(2,3) 
a


N <- 6.02e23
N
x <- 2/0
x
exp(x)
exp(-x)
x - x


a <- c("alto", "medio", "bajo")
a
is.vector(a)
a <- as.factor(a)
a
is.vector(a)
is.factor(a)
a <- as.matrix(a)
a
is.factor(a)
is.matrix(a)






############# Lectura de Datos ##############

MEXpob <- read.table('MEXpob.txt', header=TRUE)
MEXpob

plot(Pob. ~ A?o, data=MEXpob, pch=16)

read.table(file.choose(), header = T)

read.dbf('MEXPob.dbf')

bandaelastica <- data.frame(estiramiento=c(46,54,48,50,44,42,52), 
                 distancia=c(148,182,173,166,109,141,166))
bandaelastica

data.entry(bandaelastica)





################# Funciones ##################

x <- c(1, 1.5, 2, 2.5)
x
x <- c(x,3)
x
y <- c('esto','es','un','ejemplo')
y
z <- c(x, 'a')
z

seq(0,100,5)
seq(1955,1966,1)
seq(10,12,0.2)

seq(1955,1966)
seq(5)
b <- 1:10
b
50:60 /5
seq(10,1,-1)

rep(10,3)
rep(c(0,5), 4)
rep(c('M?','xi','co'),3)
rep(1:5,2)
rep(c(10,20),c(2,4))
rep(1:3,1:3)
rep(1:3,rep(4,3))
rep(c(1,2,3,4), length=10)

## Funciones est?ndar ##

round(12.345)
round(12.345,2)
trunc(12.345)
floor(12.345)
ceiling(12.345)
trunc(-12.345)
floor(-12.345)
ceiling(-12.345)


## Funciones num?ricas ##

x <- c(3,4,-7,12,9,-2,-23,-2,33,1)
x
abs(x)
sign(x)
sum(x)
prod(x)
cumsum(x)
cumprod(x)
min(x)
max(x)
cummin(x)
cummax(x)
range(x)
sort(x)
rev(x)
duplicated(x) 
unique(x) 

y <- c(23,12,-8,9,32,17,5,3)
union(x,y)
intersect(x,y)
setdiff(x,y)
is.element(4,y)
is.element(17,y)

3 %/% 2
floor(3/2)

x <- 1:10
x%%3 == 0
x[x%%3 == 0]


## Expresiones l?gicas ##

x <- 1:6
x > 2 & x <= 4
x <= 2 | x > 4
x <= 2 & x > 4
xor(x > 2 , x < 4)
! x<2





################# Ejercicio 6 ##################


a <- round(runif(100, 0, 50))
a
# Conjunto b = {2,3,6,7,8,19,22,27,31,25,37,39,44}




################# El Operador ?ndice ##################

letters
letters[5]
letters[c(2,8,16)]
letters[-5]
letters[-c(2,8,16)]

a <- 1:26
a < 13 
a[a < 13] 

trees
which(trees$Volume > 50)
trees[which(trees$Volume > 50),]



################# Operaciones con vectores ##################

a <- 5:2
b <- (1:4)*2
a
b
a+b
a-b
a*b
a/b
a**b
2*a
d <- rep(2,4)
a + b + d

x <- round(runif(500, 0, 1000))
y <- round(runif(500, 0, 1000))
x
y
z <- log( (x^2 + 2*y) / (x + y)^2 )




################# Ejercicio 8 ##################

v1 <- round(runif(100, 0, 50))
v1




################# Matrices ##################

matrix(1:6)
matrix(1:6, nrow=3)
matrix(1:12, nrow=3, byrow =T)

A <- matrix(1:6, nrow=3, byrow=T)
B <- matrix(seq(0, 10, 2), 3, 2)
A
B

A + B
A - B

A + 2
B / 2

cbind(A,4:6)
rbind(B,c(5,7))

rownames(A) <- c('R1','R2','R3') 
colnames(A) <- c('C1', 'C2')
A




################# Data Frames ##################

enut2014 <- read.csv("enut2014.csv", header = T)
dim(enut2014)
is.data.frame(enut2014)
str(enut2014)
names(enut2014)
summary(enut2014)

enut2014$edad
enut2014["edad"]

enut2014$edad[1:100]
enut2014[1:100,"edad"]


PIB <- c(208,1432,2112,259)
Pob <- c(8,61,82,7)
Infl <- c(2.4, 1.7, 2.0, 1.6)
paises <- data.frame(cbind(PIB,Pob,Infl))
rownames(paises) <- c('Austria', 'Francia', 'Alemania', 'Suiza')
rm(PIB)
rm(Pob)
rm(Infl)

paises

paises['Alemania','PIB']
paises['Suiza','Infl']
paises['Francia','Pob']
paises[1:3,'Pob']
paises[3,2]
paises[,'Infl']
paises[,2]
paises[,1:2]
paises['Alemania',]
paises[c(2,4),]

paises[Infl < 2,]
paises[Infl < 2,1:2]

paises$Pob
paises["Pob"]


## Attach y detach
Pob <- 110 #Poblaci?n de M?xico
Pob
attach(paises)
Infl
PIB
Pob
paises$Pob

detach(paises)
PobMex2010 <- Pob
rm(Pob)
attach(paises)
Pob
detach(paises)

attributes(paises)



################# Caso Pr?ctico de Data Frames ##################

attach(enut2014)
jef_enut <- enut2014[paren == 1 , c('edad','sexo','derh_sal')]
dim(jef_enut)
str(jef_enut)
names(jef_enut)

names(enut2014)[c(14:17,8:9)]

jef_enut <- cbind (jef_enut, enut2014[paren == 1 , c(8,9,14:17)] )
str(jef_enut)

detach(enut2014)


### Horas semanales de trabajo ###

attach(jef_enut)

jef_enut$hortrab <- p5_3_1 + p5_3_2/60 + p5_3_3 + p5_3_4/60

hortrab[1:100]

detach(jef_enut)

attach(jef_enut)

hortrab[1:100]

plot(density(hortrab))

plot(density(hortrab, na.rm = T), 
 xlab = "Horas",
 main = "Horas semanales de trabajo de los jefes del hogar")

jef_hombr  <- subset(jef_enut, sexo == 1)



############## La funci?n apply ##################

apply(paises, 2, max)

apply(iris3, 2, mean)


############### Datos faltantes ####################

aa <- c(1:3, ,9)

aa <- c(1:3,NA,9)
aa

aa == NA

aa > 2
aa[aa>2]

is.na(aa)
aa[is.na(aa)]
aa[!is.na(aa)]

(bb <- 1:9)
is.na(bb)[6] <- T
bb

0/0
is.na(0/0)

(cc <- c(1, 1/0, 0/0, NA))
is.na(cc)
is.finite(cc)
is.infinite(cc)
is.nan(cc)



################# Caracteres ###################

(tt <- c('esta es una prueba','otra','y otra mas'))
nchar(tt)

paste(c('Altura','Peso'), rep(c(1,2),c(2,2)))

paste(c('X','Y'), 1:4, sep='')

paste(c('X','Y'), 1:4, sep='',collapse='+')



############## Iteraciones ####################

x <- 1:50000
y <- x^2
z <- vector()
for (i in 1:50000) z[i] <- x[i]^2

for (i in 1:10) {print (i)}

for (i in c(3,2,9,6)) {print (i^2)}

## While ##
n <- 0
suma <- 0
while (suma <= 1000)
{ 
  n <- n+1
  suma <- suma + n
}
suma
n

## Vectorizaci?n ##

n <- 1:1000
su <- cumsum (n)
su [su > 1000][1]
n [su > 1000][1]





























